from pyspark.sql.functions import explode, monotonically_increasing_id, explode_outer, col, struct, collect_set, posexplode_outer, row_number
import pyspark.sql.functions as F
from pyspark.sql import Window
from pyspark.sql.functions import broadcast, spark_partition_id
from databricks.sdk.runtime import *
import re
import time


def clean_up_alligators(text):
    newtext = re.sub(r'<[^<>]*>', '', text)
    if text==newtext:
        return text
    else:
        return clean_up_alligators(newtext)


def pass_down_prefix(lst, sep, dropLevelNames):
    if len(lst)>1 and not dropLevelNames:
        return [lst[0]+sep+lst[1]]+lst[2:]
    elif len(lst)>1:
        return lst[1:]
    else:
        return lst


def flatten_structs(data, sep, dropLevelNames):
    struct_columns = [(column_name, column_dtype) for column_name, column_dtype in data.dtypes if column_dtype.startswith("struct")]
    for column_flatten, column_dtype in struct_columns:
        for column_to_shorten in [column[:column.find(":")] for column in clean_up_alligators(column_dtype[len("struct<"):-1]).split(",")]:
            data = data.withColumn((column_flatten+sep if not dropLevelNames else "") + column_to_shorten, col(column_flatten+'.'+column_to_shorten))
        data = data.drop(column_flatten)
    return data, [s for s,c in struct_columns]


def add_index(data, row_number_name):
    dfpartid = data.withColumn("partition_id", spark_partition_id())
    partitionsDF = dfpartid.select("partition_id").groupBy("partition_id").agg(
        F.count("*").alias("count")
        ).withColumn("count", F.sum("count").over(Window.orderBy("partition_id")) - col("count"))
    return dfpartid.join(
        broadcast(partitionsDF), 
        "partition_id"
        ).withColumn("row_number_within_partition", row_number().over(Window.partitionBy("partition_id").orderBy(data.columns))
        ).withColumn(row_number_name, col("count") + col("row_number_within_partition")
        ).drop("partition_id", "count", "row_number_within_partition")


def json_normalize_recursive(data, name, prefix, sep="_"):
    struct_columns=[]
    while any([column_name for column_name, column_dtype in data.dtypes if column_dtype.startswith("struct")]):
        data, more_struct_columns = flatten_structs(data, sep, False)
        struct_columns = struct_columns + more_struct_columns
    
    columns_to_explode = [column_name for column_name, column_dtype in data.dtypes if column_dtype.startswith("array")]
    prefix_name = prefix + ("_"+name if name else "")
    index_name = prefix_name + "_row_number"
    data_with_id = add_index(data, index_name).persist()
    data_with_id.select(
        list(set(data_with_id.columns) - set(columns_to_explode))
        ).write.option("overwriteSchema", "true").saveAsTable(prefix_name, mode="overwrite")
    sub_columns_to_explode = []
    for column_to_explode in columns_to_explode:
        sub_columns_to_explode += json_normalize_recursive(
            data_with_id.select(index_name, explode_outer(column_to_explode).alias(column_to_explode)), 
            column_to_explode, 
            prefix, 
            sep
            )
    data_with_id.unpersist()
    return [prefix_name] + sub_columns_to_explode


def save_and_read_intermediate_result(df, table_name):
    df.write.option("overwriteSchema", "true").saveAsTable(table_name, mode="overwrite")
    return spark.read.table(table_name)


def compress_tables(order_of_columns):
    dict_of_mapping = {}

    for column in reversed(order_of_columns):
        data = spark.read.table(column)
        if column + "_row_number" in dict_of_mapping:
            for c in dict_of_mapping[column + "_row_number"]:
                data = data.join(spark.read.table(c), column + "_row_number")
        
        data_without_column = data.drop(column + "_row_number")
        higher_id_name = [c for c in data_without_column.columns if c.endswith("_row_number")]
        distinct_objects = save_and_read_intermediate_result(
            add_index(data_without_column.drop(*higher_id_name).distinct(), column + "_individual_object_id"),
            column+"_distinct_objects"
            )
        data_grouped = data_without_column.join(
            distinct_objects, 
            [data_without_column[c].eqNullSafe(distinct_objects[c]) for c in data_without_column.columns if not c.endswith("_row_number")]
            ).groupBy(
                higher_id_name
                ).agg(collect_set(column + "_individual_object_id").alias(column + "_individual_object_ids"))
        new_data = save_and_read_intermediate_result(
            add_index(data_grouped.drop(*higher_id_name).distinct(), column + "_better_number"), 
            column+"_distinct_lists"
            )
        new_data.select(
            explode(column+"_individual_object_ids").alias(column+"_individual_object_ids"), 
            column + "_better_number"
            ).write.option("overwriteSchema", "true").saveAsTable(column+"_distinct_elements", mode="overwrite")
        new_data.join(
            data_grouped, 
            column + "_individual_object_ids"
            ).drop(
                column + "_individual_object_ids"
                ).write.option("overwriteSchema", "true").saveAsTable(column+"_mapping", mode="overwrite")
        for h in higher_id_name:
            if h in dict_of_mapping:
                dict_of_mapping[h] = dict_of_mapping[h]+[column+"_mapping"]
            else:
                dict_of_mapping[h] = [column+"_mapping"]


def delete_duped_tables(data_prefix):
    allt = spark.sql(f"""SHOW TABLES LIke '{data_prefix}*'""").select("tableName").collect()
    for table_to_be_deleted in [t[0] for t in allt if not '_distinct_elements' in t[0] and not '_distinct_objects' in t[0]]:
        spark.sql(f"drop table {table_to_be_deleted}")
    return [t[0] for t in allt if '_distinct_elements' in t[0] or '_distinct_objects' in t[0]]


def convert_to_csv(tables_to_convert, csv_path):
    tsize = 0
    for table in tables_to_convert:
        spark.table(table).repartition(1).write.csv(csv_path + table[(table.rfind(".")+1):], mode="overwrite")
        isize = max([f[2] for f in dbutils.fs.ls(csv_path + table[(table.rfind(".")+1):])])
        for csv in dbutils.fs.ls(csv_path+table[(table.rfind(".")+1):]):
            if csv[0].endswith(".csv"):
                dbutils.fs.mv(csv[0], csv_path+table[(table.rfind(".")+1):]+".csv")
        dbutils.fs.rm(csv_path+table[(table.rfind(".")+1):], True)
        tsize += isize

    return tsize


def proper_json_normalize(df, path_to_tables, csv_path=None):
    """
    Normalizes a dataframe of structured data across multiple tables.


    Parameters:
    df (pyspark.sql.DataFrame): The data as a pyspark dataframe.
    path_to_table (string): The path to tables: will serve as prefix to all data written.
    csv_path (string): Specify if you wish the data to be written to CSVs in addition to tables.

    Returns:
    list[str]: The names of the generated table
    """
    order_of_columns = json_normalize_recursive(df, None, path_to_tables)
    compress_tables(order_of_columns)
    final_tables = delete_duped_tables(path_to_tables)
    if csv_path:
        convert_to_csv(final_tables, csv_path)
    return final_tables
